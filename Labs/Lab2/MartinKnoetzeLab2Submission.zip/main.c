/**
 * CMPT464 Lab 1
 * Martin Knoetze
 * SN: 3086754
 *
 * main.c
 */

#include "button_display.h"


int main(void)
{
    setup_buttons();
    PRCMSleep();
	return 0;
}
