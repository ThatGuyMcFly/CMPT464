

/**
 * main.c
 */
#include "header.h"
int main(void)
{
    runpresentation();
    PRCMSleep();
	return 0;
}
