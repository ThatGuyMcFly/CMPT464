var group___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x =
[
    [ "rfc_CMD_BLE_GENERIC_RX_s", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html", [
      [ "bEnaCmd", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#a57e65a848a0e0f3cc1ef680c4db8d532", null ],
      [ "bOverride", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#a22f9f995b81dde2cb89fa39f03efd027", null ],
      [ "channel", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#a7cb92bc6a0d43de22d6e7ecd4250402d", null ],
      [ "commandNo", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#aee26dc444b75163c4ad4585f8a2573ad", null ],
      [ "condition", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#a64a5ff47ce7298654ec981aeac576200", null ],
      [ "init", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#adc5e8797f03c40eff5f233ed267093c0", null ],
      [ "nSkip", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#a1969a55f1a92ded766f33e7000298420", null ],
      [ "pastTrig", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#a0960665e622a68f486e043f6be82cf5f", null ],
      [ "pNextOp", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#a263681d75ed0ddb0bd7ef9f2f4c2691c", null ],
      [ "pOutput", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#a92360fa464d8ec1f7e6cfb2db203b799", null ],
      [ "pParams", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#a7c374bef8fd4a58b1b90aaa87f011976", null ],
      [ "rule", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#a0d714dd5d3c9cbe02375cc28d5533ad9", null ],
      [ "startTime", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#aae114d01d6e224bd7d9eb0f6643e8a64", null ],
      [ "startTrigger", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#af3a8dcb2ec8f192a65dd131db4dd9149", null ],
      [ "status", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#a4dc9ca2814939e15ec7741dbcffdcdcb", null ],
      [ "triggerNo", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#a7fe75b81bd4ace89fc29b2e67c541fc2", null ],
      [ "triggerType", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#adc2d833f6be6cd64183031d08a61faef", null ],
      [ "whitening", "structrfc___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x__s.html#ab4f97f8dd048b54f1146e6343b16994d", null ]
    ] ],
    [ "CMD_BLE_GENERIC_RX", "group___c_m_d___b_l_e___g_e_n_e_r_i_c___r_x.html#ga8ffad7b020e36eb4b9a4b02c8b3fac53", null ]
];