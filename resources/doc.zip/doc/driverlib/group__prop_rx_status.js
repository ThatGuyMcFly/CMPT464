var group__prop_rx_status =
[
    [ "rfc_propRxStatus_s", "structrfc__prop_rx_status__s.html", [
      [ "addressInd", "structrfc__prop_rx_status__s.html#a2e5e29cffe832dd1c94bf75d52ca9908", null ],
      [ "result", "structrfc__prop_rx_status__s.html#a409cb7a1aa48cbd737d384430fb6de52", null ],
      [ "status", "structrfc__prop_rx_status__s.html#a6e7316f3192f46fa5091c06b2e4c8e38", null ],
      [ "syncWordId", "structrfc__prop_rx_status__s.html#abfb08515a7e5b45f0bb9f15ab1bfdac2", null ]
    ] ]
];