var group___c_m_d___p_r_o_p___s_e_t___l_e_n =
[
    [ "rfc_CMD_PROP_SET_LEN_s", "structrfc___c_m_d___p_r_o_p___s_e_t___l_e_n__s.html", [
      [ "commandNo", "structrfc___c_m_d___p_r_o_p___s_e_t___l_e_n__s.html#aaa8f52cd0dbecea83b0f65cf05b11bad", null ],
      [ "rxLen", "structrfc___c_m_d___p_r_o_p___s_e_t___l_e_n__s.html#a5426f6031a9665d51071a73aaedb26fb", null ]
    ] ],
    [ "CMD_PROP_SET_LEN", "group___c_m_d___p_r_o_p___s_e_t___l_e_n.html#ga50c46c39ab723fa199ee232120699da9", null ]
];