var group___c_m_d___s_c_h___i_m_m =
[
    [ "rfc_CMD_SCH_IMM_s", "structrfc___c_m_d___s_c_h___i_m_m__s.html", [
      [ "__dummy0", "structrfc___c_m_d___s_c_h___i_m_m__s.html#a9f092154bc67890780271d92d56e6a74", null ],
      [ "bEnaCmd", "structrfc___c_m_d___s_c_h___i_m_m__s.html#a73a1822fb9be1445abb4132eb8e3cf3f", null ],
      [ "cmdrVal", "structrfc___c_m_d___s_c_h___i_m_m__s.html#a4da376bc319d5a8b0db42dd5a3b50a45", null ],
      [ "cmdstaVal", "structrfc___c_m_d___s_c_h___i_m_m__s.html#a4c56e50c7ed350d8d712bfe4d50fefe7", null ],
      [ "commandNo", "structrfc___c_m_d___s_c_h___i_m_m__s.html#a4be29739754b0f9ebd56ae857314e451", null ],
      [ "condition", "structrfc___c_m_d___s_c_h___i_m_m__s.html#a1c1fb39e5f32d57bfcd6ca51ed396307", null ],
      [ "nSkip", "structrfc___c_m_d___s_c_h___i_m_m__s.html#af038795e1604858e5232209cb25a985e", null ],
      [ "pastTrig", "structrfc___c_m_d___s_c_h___i_m_m__s.html#a87f1029281ed478d2f05168e605a6309", null ],
      [ "pNextOp", "structrfc___c_m_d___s_c_h___i_m_m__s.html#a0fd70c31c65520702b5149c9e2244346", null ],
      [ "rule", "structrfc___c_m_d___s_c_h___i_m_m__s.html#ab0680e1bad9401410c00683bc6927f7a", null ],
      [ "startTime", "structrfc___c_m_d___s_c_h___i_m_m__s.html#ab0da77e12db1eb294ce738c56a41e054", null ],
      [ "startTrigger", "structrfc___c_m_d___s_c_h___i_m_m__s.html#a42e6854b806cac9b2ef432e609b8bb8e", null ],
      [ "status", "structrfc___c_m_d___s_c_h___i_m_m__s.html#a15483e794ae8bc33ba573505caa2a1cd", null ],
      [ "triggerNo", "structrfc___c_m_d___s_c_h___i_m_m__s.html#a58100bf3846880b7ee6bd74d19cd4da7", null ],
      [ "triggerType", "structrfc___c_m_d___s_c_h___i_m_m__s.html#a2f7899a4cb3acfe927c433c41535faa0", null ]
    ] ],
    [ "CMD_SCH_IMM", "group___c_m_d___s_c_h___i_m_m.html#ga4ddb2bc1ff57dfdc3e712fa0265b376c", null ]
];