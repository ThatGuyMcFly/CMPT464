var group___c_m_d___r_e_m_o_v_e___d_a_t_a___e_n_t_r_y =
[
    [ "rfc_CMD_REMOVE_DATA_ENTRY_s", "structrfc___c_m_d___r_e_m_o_v_e___d_a_t_a___e_n_t_r_y__s.html", [
      [ "__dummy0", "structrfc___c_m_d___r_e_m_o_v_e___d_a_t_a___e_n_t_r_y__s.html#ae312d2e362fd8906059d754b563b2b30", null ],
      [ "commandNo", "structrfc___c_m_d___r_e_m_o_v_e___d_a_t_a___e_n_t_r_y__s.html#aaf323dc6adc705963160e9300b74dcbd", null ],
      [ "pEntry", "structrfc___c_m_d___r_e_m_o_v_e___d_a_t_a___e_n_t_r_y__s.html#a198202b05ed0e74b1cb3026d8f92d4aa", null ],
      [ "pQueue", "structrfc___c_m_d___r_e_m_o_v_e___d_a_t_a___e_n_t_r_y__s.html#a87adbf71c3c1c6d2ef96786944a47aea", null ]
    ] ],
    [ "CMD_REMOVE_DATA_ENTRY", "group___c_m_d___r_e_m_o_v_e___d_a_t_a___e_n_t_r_y.html#ga1b842b5fb04d81032fec254339344b8a", null ]
];