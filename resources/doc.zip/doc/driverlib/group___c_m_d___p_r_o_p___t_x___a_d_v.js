var group___c_m_d___p_r_o_p___t_x___a_d_v =
[
    [ "rfc_CMD_PROP_TX_ADV_s", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html", [
      [ "__pad0__", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#abbf3da5d355197ecbaeaa18b31e3c7ba", null ],
      [ "bCrcIncHdr", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#ac3db527b90d54d3b92e60a0f05f45d1c", null ],
      [ "bCrcIncSw", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#ac61368cafa4b8cbc0cf3854c30e05d01", null ],
      [ "bEnaCmd", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#a647db7078ee9f251064d66007e787695", null ],
      [ "bExtTxTrig", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#a30b6c100c870225b370cfa5f310dca2e", null ],
      [ "bFsOff", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#aa3ae3c2e1381250e84a9b756a3a88823", null ],
      [ "bUseCrc", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#a8d38078597590556e27b4f59231bb091", null ],
      [ "commandNo", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#af44cf688aa94bf1fbb16866777460519", null ],
      [ "condition", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#adb24fdccbafa9e214f212ac050ea0ea0", null ],
      [ "inputMode", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#a2db76fa0f3e46139f59c66c85ab84db2", null ],
      [ "nSkip", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#a9f37cade22807516464073a424f57545", null ],
      [ "numHdrBits", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#a84d43a53c850f14f22bf2ee7db75ff22", null ],
      [ "pastTrig", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#a04a46977f676b00ecbfb2d1a72a26896", null ],
      [ "pktConf", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#a5e6ec6e423e0ab34887750c517b0ce68", null ],
      [ "pktLen", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#a0cb8e41cbb12bcbbb21076e03eab1796", null ],
      [ "pNextOp", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#a6e93b06aa2d40eb643cf545398c92fbe", null ],
      [ "pPkt", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#a620d6f39585be5db6362e6aa2911dcea", null ],
      [ "preTime", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#a7a6b2d6ee8e98f612bf1f83bc98acdd2", null ],
      [ "preTrigger", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#af69bd48744a802fffedf29ba2be54d9d", null ],
      [ "rule", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#a950fa23295ee320a27e7c9eb50ed11ff", null ],
      [ "source", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#ab4bf929d0b00d9b8f7511a3479e28814", null ],
      [ "startConf", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#aedd6cda3585052b220d80d7370ba8fbb", null ],
      [ "startTime", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#a6708caf6abc0b4fdadc5fa89a6ade957", null ],
      [ "startTrigger", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#ab11658d0c015597825b380434e830c00", null ],
      [ "status", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#a32b75ffa972339c45494015bed84b195", null ],
      [ "syncWord", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#a7a960f85aec51c1f135f6f16b1e4c248", null ],
      [ "triggerNo", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#a56d828a5631c1b3c009a5bb7d635e029", null ],
      [ "triggerType", "structrfc___c_m_d___p_r_o_p___t_x___a_d_v__s.html#ae4ce191231c1f1c54a44b7ca20aa111b", null ]
    ] ],
    [ "CMD_PROP_TX_ADV", "group___c_m_d___p_r_o_p___t_x___a_d_v.html#ga601a9a3d01e65feb5bc4e65db12c8a80", null ]
];