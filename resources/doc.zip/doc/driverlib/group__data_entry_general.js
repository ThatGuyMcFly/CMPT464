var group__data_entry_general =
[
    [ "rfc_dataEntryGeneral_s", "structrfc__data_entry_general__s.html", [
      [ "config", "structrfc__data_entry_general__s.html#a78af618db69629e0b6ce7d038858a7e6", null ],
      [ "data", "structrfc__data_entry_general__s.html#af596ddab8b78b52278a714a2db09e5c6", null ],
      [ "irqIntv", "structrfc__data_entry_general__s.html#a9131d5870977029e36ce5d2da16e61a6", null ],
      [ "length", "structrfc__data_entry_general__s.html#a7ea2f37c94eacc6c27406d165c0804fa", null ],
      [ "lenSz", "structrfc__data_entry_general__s.html#a4da6c03a19da701614685b23cf56f8ed", null ],
      [ "pNextEntry", "structrfc__data_entry_general__s.html#a9073dedc1a0a761159e2cc36ac48daf2", null ],
      [ "status", "structrfc__data_entry_general__s.html#a4aaf454d05a1a7509a15c72e6152da15", null ],
      [ "type", "structrfc__data_entry_general__s.html#ad280df79a4db7c00b1a02026a1b73404", null ]
    ] ]
];