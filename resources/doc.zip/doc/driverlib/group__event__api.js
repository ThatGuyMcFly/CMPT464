var group__event__api =
[
    [ "EventRegister", "group__event__api.html#ga0789d3fd77e8aa533d45b81e5bbee62e", null ],
    [ "EventSwEventClear", "group__event__api.html#ga6911e40dbe57bddf3360b3d12683f893", null ],
    [ "EventSwEventGet", "group__event__api.html#gabe7a040af712a5cdc36c788be5412104", null ],
    [ "EventSwEventSet", "group__event__api.html#ga2a3eae172a43e00b52be26f5ba704786", null ]
];