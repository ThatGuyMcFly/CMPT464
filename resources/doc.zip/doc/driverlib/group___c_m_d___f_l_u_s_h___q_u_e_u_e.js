var group___c_m_d___f_l_u_s_h___q_u_e_u_e =
[
    [ "rfc_CMD_FLUSH_QUEUE_s", "structrfc___c_m_d___f_l_u_s_h___q_u_e_u_e__s.html", [
      [ "__dummy0", "structrfc___c_m_d___f_l_u_s_h___q_u_e_u_e__s.html#a81a4565a2ddc596cc1090768bcbf4978", null ],
      [ "commandNo", "structrfc___c_m_d___f_l_u_s_h___q_u_e_u_e__s.html#a8a798cdbc5e56ae0b954eb680bf60098", null ],
      [ "pFirstEntry", "structrfc___c_m_d___f_l_u_s_h___q_u_e_u_e__s.html#a8f27ceb275314888ae69822531078523", null ],
      [ "pQueue", "structrfc___c_m_d___f_l_u_s_h___q_u_e_u_e__s.html#a7b9a93ae1d7971fde4215c3ac0d1ffe9", null ]
    ] ],
    [ "CMD_FLUSH_QUEUE", "group___c_m_d___f_l_u_s_h___q_u_e_u_e.html#ga3d6c3a57ece843509027116b0797a2e2", null ]
];