var group___c_m_d___a_d_d___d_a_t_a___e_n_t_r_y =
[
    [ "rfc_CMD_ADD_DATA_ENTRY_s", "structrfc___c_m_d___a_d_d___d_a_t_a___e_n_t_r_y__s.html", [
      [ "__dummy0", "structrfc___c_m_d___a_d_d___d_a_t_a___e_n_t_r_y__s.html#ae41fd6494d9690ec66fe337c6d5ce1e8", null ],
      [ "commandNo", "structrfc___c_m_d___a_d_d___d_a_t_a___e_n_t_r_y__s.html#a5f28e9d45ca9a01abc8b88b954fc6120", null ],
      [ "pEntry", "structrfc___c_m_d___a_d_d___d_a_t_a___e_n_t_r_y__s.html#a4010203e00fe7becdddf238957ef0950", null ],
      [ "pQueue", "structrfc___c_m_d___a_d_d___d_a_t_a___e_n_t_r_y__s.html#afa4d927a9fdb47d53c7c7c0151e50ec0", null ]
    ] ],
    [ "CMD_ADD_DATA_ENTRY", "group___c_m_d___a_d_d___d_a_t_a___e_n_t_r_y.html#gabfc912451851385cbe51c5db7d2496fc", null ]
];