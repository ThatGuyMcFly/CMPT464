var group__ble_master_slave_par =
[
    [ "rfc_bleMasterSlavePar_s", "structrfc__ble_master_slave_par__s.html", [
      [ "accessAddress", "structrfc__ble_master_slave_par__s.html#a752b7afb91a4a95fd6ba1782b166588f", null ],
      [ "bAppendRssi", "structrfc__ble_master_slave_par__s.html#a503bfed21c60c009fcc332da7a3c4e21", null ],
      [ "bAppendStatus", "structrfc__ble_master_slave_par__s.html#aff35fe83ba5bbd6fe0e8ea76bc829b0f", null ],
      [ "bAppendTimestamp", "structrfc__ble_master_slave_par__s.html#a5eb325115a31cd7f50cb259e03e21645", null ],
      [ "bAutoEmpty", "structrfc__ble_master_slave_par__s.html#a5d7304312b7cb61a91cce7be31a57eac", null ],
      [ "bAutoFlushCrcErr", "structrfc__ble_master_slave_par__s.html#a5210c2d445e117089c99ddd5c6331c38", null ],
      [ "bAutoFlushEmpty", "structrfc__ble_master_slave_par__s.html#ad29bbb8d0c3cd087ce3790f31c70bffa", null ],
      [ "bAutoFlushIgnored", "structrfc__ble_master_slave_par__s.html#a43743c8ccf5239daca9aebf023d24a24", null ],
      [ "bFirstPkt", "structrfc__ble_master_slave_par__s.html#a5d51fe4509764d780a51e1246869091d", null ],
      [ "bIncludeCrc", "structrfc__ble_master_slave_par__s.html#a916c0c46d6bc49d2bf1620405b5778f6", null ],
      [ "bIncludeLenByte", "structrfc__ble_master_slave_par__s.html#adb92aab650f45d9f52da9a4cee635afc", null ],
      [ "bLlCtrlAckPending", "structrfc__ble_master_slave_par__s.html#a2de60c1efbc639c16e908362e1785a51", null ],
      [ "bLlCtrlAckRx", "structrfc__ble_master_slave_par__s.html#aa6d91f59150a79c273c107fd4d44c876", null ],
      [ "bLlCtrlTx", "structrfc__ble_master_slave_par__s.html#a11c5d7dfce531af5b9fcf48d4fc40f2e", null ],
      [ "crcInit0", "structrfc__ble_master_slave_par__s.html#a8728781b8f21aa127fa43edcf2e10e2d", null ],
      [ "crcInit1", "structrfc__ble_master_slave_par__s.html#a9f21edd80a9b438a64c942f1a6579059", null ],
      [ "crcInit2", "structrfc__ble_master_slave_par__s.html#a76f682951c9e536049787de8ed63bcd0", null ],
      [ "lastRxSn", "structrfc__ble_master_slave_par__s.html#ab7db3f4aa0ef5f1e1d96a9ec73e299d9", null ],
      [ "lastTxSn", "structrfc__ble_master_slave_par__s.html#a8f3209e9226b15f5187e5af1e46646ee", null ],
      [ "maxNack", "structrfc__ble_master_slave_par__s.html#a90e70e46e148aaa32e86b38bc65adbd1", null ],
      [ "maxPkt", "structrfc__ble_master_slave_par__s.html#a967c19339d587531b4ef8c9f261f04e2", null ],
      [ "nextTxSn", "structrfc__ble_master_slave_par__s.html#a574951679a02e9addbdfc29794edbe92", null ],
      [ "pRxQ", "structrfc__ble_master_slave_par__s.html#a28140bd2052ce081431fbc5dabca0035", null ],
      [ "pTxQ", "structrfc__ble_master_slave_par__s.html#a4479ec39ed285eed5ace81ce9414dce9", null ],
      [ "rxConfig", "structrfc__ble_master_slave_par__s.html#a6be0374c13512410ee7ee6fc79f7d494", null ],
      [ "seqStat", "structrfc__ble_master_slave_par__s.html#af4b9e076042872a94540cd10d64b8d6f", null ]
    ] ]
];