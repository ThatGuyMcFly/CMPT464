var group___c_m_d___u_p_d_a_t_e___r_a_d_i_o___s_e_t_u_p =
[
    [ "rfc_CMD_UPDATE_RADIO_SETUP_s", "structrfc___c_m_d___u_p_d_a_t_e___r_a_d_i_o___s_e_t_u_p__s.html", [
      [ "__dummy0", "structrfc___c_m_d___u_p_d_a_t_e___r_a_d_i_o___s_e_t_u_p__s.html#a7cb4157239d4dee3ffa2e0c1f00c183e", null ],
      [ "commandNo", "structrfc___c_m_d___u_p_d_a_t_e___r_a_d_i_o___s_e_t_u_p__s.html#a6a4d66a87a4167885c3962e3b0f6a4c3", null ],
      [ "pRegOverride", "structrfc___c_m_d___u_p_d_a_t_e___r_a_d_i_o___s_e_t_u_p__s.html#a958f779b86a5257fa1dbf24d7c51baa1", null ]
    ] ],
    [ "CMD_UPDATE_RADIO_SETUP", "group___c_m_d___u_p_d_a_t_e___r_a_d_i_o___s_e_t_u_p.html#ga3bd67a2450f5e368f0671b3e3950d07d", null ]
];