var group___c_m_d___s_y_n_c___s_t_o_p___r_a_t =
[
    [ "rfc_CMD_SYNC_STOP_RAT_s", "structrfc___c_m_d___s_y_n_c___s_t_o_p___r_a_t__s.html", [
      [ "__dummy0", "structrfc___c_m_d___s_y_n_c___s_t_o_p___r_a_t__s.html#ad4e6d50baaf4910309282e40d6b53774", null ],
      [ "bEnaCmd", "structrfc___c_m_d___s_y_n_c___s_t_o_p___r_a_t__s.html#a492fcf483a20bbc277b8924b40a6981c", null ],
      [ "commandNo", "structrfc___c_m_d___s_y_n_c___s_t_o_p___r_a_t__s.html#a5f953d50e01f4a01856237f460b4fee1", null ],
      [ "condition", "structrfc___c_m_d___s_y_n_c___s_t_o_p___r_a_t__s.html#aaccc63df78e9ba0b72f8e8cbaf1d6c3a", null ],
      [ "nSkip", "structrfc___c_m_d___s_y_n_c___s_t_o_p___r_a_t__s.html#aa89aff00898f1530a7eea834fb0343f6", null ],
      [ "pastTrig", "structrfc___c_m_d___s_y_n_c___s_t_o_p___r_a_t__s.html#a418b0da2da5727f05d4ccb554614c7e2", null ],
      [ "pNextOp", "structrfc___c_m_d___s_y_n_c___s_t_o_p___r_a_t__s.html#a8267a54424dfc72893f4e4e7cc29c5db", null ],
      [ "rat0", "structrfc___c_m_d___s_y_n_c___s_t_o_p___r_a_t__s.html#a6a1c4d91d2c72caaea5d6f124f260e1b", null ],
      [ "rule", "structrfc___c_m_d___s_y_n_c___s_t_o_p___r_a_t__s.html#a5fe0fc532613e5cbb827eb4c0ac23364", null ],
      [ "startTime", "structrfc___c_m_d___s_y_n_c___s_t_o_p___r_a_t__s.html#a952461c84e8e85fbd5c6c154d63c9b52", null ],
      [ "startTrigger", "structrfc___c_m_d___s_y_n_c___s_t_o_p___r_a_t__s.html#a7d02cdd00e6f2b029df1d07f604556d2", null ],
      [ "status", "structrfc___c_m_d___s_y_n_c___s_t_o_p___r_a_t__s.html#a50ced01615a8e124b203c5a70213ef1e", null ],
      [ "triggerNo", "structrfc___c_m_d___s_y_n_c___s_t_o_p___r_a_t__s.html#afa05dcf8cf092e6f7a7920ad9103deae", null ],
      [ "triggerType", "structrfc___c_m_d___s_y_n_c___s_t_o_p___r_a_t__s.html#a83b1a6d49cd324ce1e5c41c7744c9635", null ]
    ] ],
    [ "CMD_SYNC_STOP_RAT", "group___c_m_d___s_y_n_c___s_t_o_p___r_a_t.html#ga3cb5193a0a1c5470280bdb63fb79c814", null ]
];