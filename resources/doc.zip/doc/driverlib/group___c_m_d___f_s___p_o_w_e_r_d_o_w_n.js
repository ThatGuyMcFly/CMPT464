var group___c_m_d___f_s___p_o_w_e_r_d_o_w_n =
[
    [ "rfc_CMD_FS_POWERDOWN_s", "structrfc___c_m_d___f_s___p_o_w_e_r_d_o_w_n__s.html", [
      [ "bEnaCmd", "structrfc___c_m_d___f_s___p_o_w_e_r_d_o_w_n__s.html#aad06e7f3c41ad9da081dbf6bfe73b18e", null ],
      [ "commandNo", "structrfc___c_m_d___f_s___p_o_w_e_r_d_o_w_n__s.html#a044365ac5f610db0b2045f320056563a", null ],
      [ "condition", "structrfc___c_m_d___f_s___p_o_w_e_r_d_o_w_n__s.html#a84b9be2a2c9a8da8075a289e0499d23e", null ],
      [ "nSkip", "structrfc___c_m_d___f_s___p_o_w_e_r_d_o_w_n__s.html#ade4b6ef1926d72105800124843101afd", null ],
      [ "pastTrig", "structrfc___c_m_d___f_s___p_o_w_e_r_d_o_w_n__s.html#aaa5518bf069fc6e6e0415b5d2500bd11", null ],
      [ "pNextOp", "structrfc___c_m_d___f_s___p_o_w_e_r_d_o_w_n__s.html#a7e57c8226544c25ed6bb99a2d6ad3ddb", null ],
      [ "rule", "structrfc___c_m_d___f_s___p_o_w_e_r_d_o_w_n__s.html#a14d549eb2f42374cd24babcf7fe3e88a", null ],
      [ "startTime", "structrfc___c_m_d___f_s___p_o_w_e_r_d_o_w_n__s.html#a8dab475b6ac2223743b48ba1e6eeff04", null ],
      [ "startTrigger", "structrfc___c_m_d___f_s___p_o_w_e_r_d_o_w_n__s.html#a3221773f065f1d6b80fbf59c3d143589", null ],
      [ "status", "structrfc___c_m_d___f_s___p_o_w_e_r_d_o_w_n__s.html#a5b78330b95d34968df53c342b173ff4c", null ],
      [ "triggerNo", "structrfc___c_m_d___f_s___p_o_w_e_r_d_o_w_n__s.html#acd1ea1d3683f1669916057268bee1472", null ],
      [ "triggerType", "structrfc___c_m_d___f_s___p_o_w_e_r_d_o_w_n__s.html#a6d04f7a3e98a2d187bd3f4f9552fb4c4", null ]
    ] ],
    [ "CMD_FS_POWERDOWN", "group___c_m_d___f_s___p_o_w_e_r_d_o_w_n.html#gae6f0d19638f79effbed6288670a51627", null ]
];