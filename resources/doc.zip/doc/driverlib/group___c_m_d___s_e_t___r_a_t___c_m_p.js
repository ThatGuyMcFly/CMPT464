var group___c_m_d___s_e_t___r_a_t___c_m_p =
[
    [ "rfc_CMD_SET_RAT_CMP_s", "structrfc___c_m_d___s_e_t___r_a_t___c_m_p__s.html", [
      [ "__dummy0", "structrfc___c_m_d___s_e_t___r_a_t___c_m_p__s.html#a930428bf7f4986dfc7a01c568a182a4c", null ],
      [ "commandNo", "structrfc___c_m_d___s_e_t___r_a_t___c_m_p__s.html#a4440630045798bc9b963779621c650bf", null ],
      [ "compareTime", "structrfc___c_m_d___s_e_t___r_a_t___c_m_p__s.html#aed866f4aafe07f07628bc67e730f7a0d", null ],
      [ "ratCh", "structrfc___c_m_d___s_e_t___r_a_t___c_m_p__s.html#adc4cd2a3a28225b55292cd461e230b2a", null ]
    ] ],
    [ "CMD_SET_RAT_CMP", "group___c_m_d___s_e_t___r_a_t___c_m_p.html#ga380b69ffdfb7608ae3c1ec6a21db6a47", null ]
];