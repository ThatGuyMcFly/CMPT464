var group___c_m_d___u_p_d_a_t_e___f_s =
[
    [ "rfc_CMD_UPDATE_FS_s", "structrfc___c_m_d___u_p_d_a_t_e___f_s__s.html", [
      [ "__dummy0", "structrfc___c_m_d___u_p_d_a_t_e___f_s__s.html#a09644ab6ffae28bef5a6950e2d30674d", null ],
      [ "__dummy1", "structrfc___c_m_d___u_p_d_a_t_e___f_s__s.html#a659c18979fbfd8e080b90d14c7195a8b", null ],
      [ "__dummy2", "structrfc___c_m_d___u_p_d_a_t_e___f_s__s.html#ad1d513e71f8322bbefdad57caa00545b", null ],
      [ "__dummy3", "structrfc___c_m_d___u_p_d_a_t_e___f_s__s.html#a69bac791db364015aba38c34812ab3c5", null ],
      [ "commandNo", "structrfc___c_m_d___u_p_d_a_t_e___f_s__s.html#a07763ea15eb772b68feee1f68148cfd9", null ],
      [ "fractFreq", "structrfc___c_m_d___u_p_d_a_t_e___f_s__s.html#ac33a3eb1178023482970a46b668722f5", null ],
      [ "frequency", "structrfc___c_m_d___u_p_d_a_t_e___f_s__s.html#ac4ddfc244ed81d13fb66394dbcf49970", null ]
    ] ],
    [ "CMD_UPDATE_FS", "group___c_m_d___u_p_d_a_t_e___f_s.html#gac1661d53e11f3013dac745c0d8cf6086", null ]
];