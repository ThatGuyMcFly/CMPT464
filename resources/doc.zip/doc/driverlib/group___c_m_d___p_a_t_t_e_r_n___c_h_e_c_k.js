var group___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k =
[
    [ "rfc_CMD_PATTERN_CHECK_s", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html", [
      [ "bBitRev", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#a0b8e266c4bea69ee02ab40a7718a301b", null ],
      [ "bByteRev", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#a03b1452ef7a2d8203423b523483632ec", null ],
      [ "bEnaCmd", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#a32c88d4e891c19201951013e1f1fc9b2", null ],
      [ "bRxVal", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#a83629fb9ff9994b206ce9a0abab3b4a0", null ],
      [ "commandNo", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#a43fba404975158038ba2c5dfab473ee6", null ],
      [ "compareVal", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#a15a88676badeedfbd1defb30904e4d5a", null ],
      [ "condition", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#aaccd1d6e02bfeffa328f10820032f467", null ],
      [ "mask", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#ae75ad8a3e5c9489b3320a7777b6a5b37", null ],
      [ "nSkip", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#a1923a3efb36b147ff6888d9fcefc49f2", null ],
      [ "operation", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#a0daa02ead7905dbab7d54c6e384421a0", null ],
      [ "pastTrig", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#aab99e5ea9c2bff43c70915bb74feed35", null ],
      [ "patternOpt", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#a14cc11a852ba99ded7525725fe68b257", null ],
      [ "pNextOp", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#a6df8c42ec747b07ccb248367177e5da6", null ],
      [ "pNextOpIfOk", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#a27743b30033ccecf79bdda22866368cd", null ],
      [ "pValue", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#ad874b7e80d386413170d003f7ae5448f", null ],
      [ "rule", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#a98302c9714b5c58ed76d939af4a61474", null ],
      [ "signExtend", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#a587a12275ad791c8b0f7a1b822fcdd1d", null ],
      [ "startTime", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#afee6ed3f0e97254b75439c0ff7b1b989", null ],
      [ "startTrigger", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#a3942129e13e12fca9439803edda5b7d9", null ],
      [ "status", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#aa642dd89102cbf900ef54c7ed8cc01e8", null ],
      [ "triggerNo", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#aeee1b5a91f426b348b2b4261a3004528", null ],
      [ "triggerType", "structrfc___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k__s.html#a402b461d4f5adc9d871bb6b4c4e24e0d", null ]
    ] ],
    [ "CMD_PATTERN_CHECK", "group___c_m_d___p_a_t_t_e_r_n___c_h_e_c_k.html#ga3242f91ba9f33752e1f39baa5a5befa6", null ]
];