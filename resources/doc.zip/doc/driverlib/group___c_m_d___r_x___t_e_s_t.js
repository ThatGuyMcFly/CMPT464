var group___c_m_d___r_x___t_e_s_t =
[
    [ "rfc_CMD_RX_TEST_s", "structrfc___c_m_d___r_x___t_e_s_t__s.html", [
      [ "bEnaCmd", "structrfc___c_m_d___r_x___t_e_s_t__s.html#a7d4923cf6a17a3effa08ae55e26d6294", null ],
      [ "bEnaFifo", "structrfc___c_m_d___r_x___t_e_s_t__s.html#af25a62062122cd2d88188aae09cc5c04", null ],
      [ "bFsOff", "structrfc___c_m_d___r_x___t_e_s_t__s.html#aa17d319341aa06c540bb0045233eb2ce", null ],
      [ "bNoSync", "structrfc___c_m_d___r_x___t_e_s_t__s.html#aa7254c6bcb204f6ed3d80ac73e703cd4", null ],
      [ "commandNo", "structrfc___c_m_d___r_x___t_e_s_t__s.html#acb81210a67f44f05b5c30ff20b3e2975", null ],
      [ "condition", "structrfc___c_m_d___r_x___t_e_s_t__s.html#abc206cb7826ad82304363cc29e16283a", null ],
      [ "config", "structrfc___c_m_d___r_x___t_e_s_t__s.html#a18a0a4eb0e565d612bc2504dfd0e74cf", null ],
      [ "endTime", "structrfc___c_m_d___r_x___t_e_s_t__s.html#a7c17a7ae01edf532e36be67db062e899", null ],
      [ "endTrigger", "structrfc___c_m_d___r_x___t_e_s_t__s.html#aec318304801939feed8d2f3551f42848", null ],
      [ "nSkip", "structrfc___c_m_d___r_x___t_e_s_t__s.html#a68310b86688b4b63739dfdcf2a038f90", null ],
      [ "pastTrig", "structrfc___c_m_d___r_x___t_e_s_t__s.html#aaefcfe5021e90496bb657b8b5ffa12a1", null ],
      [ "pNextOp", "structrfc___c_m_d___r_x___t_e_s_t__s.html#af29e3da437dc3429a7e365a81e851e47", null ],
      [ "rule", "structrfc___c_m_d___r_x___t_e_s_t__s.html#ab53e11c6c1add7e78420c3973bfb3226", null ],
      [ "startTime", "structrfc___c_m_d___r_x___t_e_s_t__s.html#a513534391675ce8804561c1be671d073", null ],
      [ "startTrigger", "structrfc___c_m_d___r_x___t_e_s_t__s.html#ada9e0083f1085d23de44848d2d02288c", null ],
      [ "status", "structrfc___c_m_d___r_x___t_e_s_t__s.html#a7a9312252fd3184b0c43bd2f9dd5098f", null ],
      [ "syncWord", "structrfc___c_m_d___r_x___t_e_s_t__s.html#a346caa273be1298ddee05050cc5292fc", null ],
      [ "triggerNo", "structrfc___c_m_d___r_x___t_e_s_t__s.html#ad1fbae01a25cba86843300af54524af2", null ],
      [ "triggerType", "structrfc___c_m_d___r_x___t_e_s_t__s.html#abcfc124489ce4059ada7fcfcec5e269c", null ]
    ] ],
    [ "CMD_RX_TEST", "group___c_m_d___r_x___t_e_s_t.html#gad198ba466d2e6fe43eac303ddcefe7ae", null ]
];