var group__data_entry_multi =
[
    [ "rfc_dataEntryMulti_s", "structrfc__data_entry_multi__s.html", [
      [ "config", "structrfc__data_entry_multi__s.html#a1283d7bbd799383a68184d62a5b6c14d", null ],
      [ "irqIntv", "structrfc__data_entry_multi__s.html#af9117a7a8a634e65203744ccc89be69d", null ],
      [ "length", "structrfc__data_entry_multi__s.html#ab58d06abfa7a6cda5417d039d7f912ce", null ],
      [ "lenSz", "structrfc__data_entry_multi__s.html#a9a9e19db0a9694f9a7b2e2fea69471b4", null ],
      [ "nextIndex", "structrfc__data_entry_multi__s.html#aba31f1b96b775b26fd036664d7d4d73b", null ],
      [ "numElements", "structrfc__data_entry_multi__s.html#ad2f528fbc4eb96a7e40ec32ede5cb17d", null ],
      [ "pNextEntry", "structrfc__data_entry_multi__s.html#afc13f84aaba660a3aca74fac3e1edff3", null ],
      [ "rxData", "structrfc__data_entry_multi__s.html#a591b1fe00ed372f82016c44a39656549", null ],
      [ "status", "structrfc__data_entry_multi__s.html#a0169720eb676febf0009921f8d7aa9f8", null ],
      [ "type", "structrfc__data_entry_multi__s.html#a8cb0862bf71e7b7b12ab74003e66b17e", null ]
    ] ]
];