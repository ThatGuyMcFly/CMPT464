var group___c_m_d___t_x___t_e_s_t =
[
    [ "rfc_CMD_TX_TEST_s", "structrfc___c_m_d___t_x___t_e_s_t__s.html", [
      [ "__dummy0", "structrfc___c_m_d___t_x___t_e_s_t__s.html#a6f4f698cd221be7f5908cd2ca3077c5c", null ],
      [ "__dummy1", "structrfc___c_m_d___t_x___t_e_s_t__s.html#a58c6a00f6a991dc5f205b840d0244e7a", null ],
      [ "bEnaCmd", "structrfc___c_m_d___t_x___t_e_s_t__s.html#a9b42635bcdddda8b12f8b2c732718fc1", null ],
      [ "bFsOff", "structrfc___c_m_d___t_x___t_e_s_t__s.html#a88d9c352b0bbb8535310be545f743a0f", null ],
      [ "bUseCw", "structrfc___c_m_d___t_x___t_e_s_t__s.html#a3dd71a31ed63000e18ae086a373f344b", null ],
      [ "commandNo", "structrfc___c_m_d___t_x___t_e_s_t__s.html#a5f447033aad17a9cc716b0154b2fbfbb", null ],
      [ "condition", "structrfc___c_m_d___t_x___t_e_s_t__s.html#ad023b6563f61acd41e0cf221b222b353", null ],
      [ "config", "structrfc___c_m_d___t_x___t_e_s_t__s.html#a486b8afbf2f9f2a4dad31a7250dfdc3a", null ],
      [ "endTime", "structrfc___c_m_d___t_x___t_e_s_t__s.html#aaee7c782121e9874f7e525378ca6d1ba", null ],
      [ "endTrigger", "structrfc___c_m_d___t_x___t_e_s_t__s.html#a1ec0c81d2e9a0c1a3f7312750dc6110b", null ],
      [ "nSkip", "structrfc___c_m_d___t_x___t_e_s_t__s.html#afbeda924b208c92fab0f56943ceaa369", null ],
      [ "pastTrig", "structrfc___c_m_d___t_x___t_e_s_t__s.html#a016226cf9f079809040b585142faa9fd", null ],
      [ "pNextOp", "structrfc___c_m_d___t_x___t_e_s_t__s.html#a8b2f499262be42857d10f517cd2ee44d", null ],
      [ "rule", "structrfc___c_m_d___t_x___t_e_s_t__s.html#a914da8e88d86da5d1ad8a25b72e54928", null ],
      [ "startTime", "structrfc___c_m_d___t_x___t_e_s_t__s.html#ab705e84b463895bcb38dd9c2f4c9054d", null ],
      [ "startTrigger", "structrfc___c_m_d___t_x___t_e_s_t__s.html#a956a7d222eb77c4c722392a3561b42d1", null ],
      [ "status", "structrfc___c_m_d___t_x___t_e_s_t__s.html#ab364fd45f44c37a6f0ed7707f387bef2", null ],
      [ "syncWord", "structrfc___c_m_d___t_x___t_e_s_t__s.html#af33aa79d604937c7c564b15722676d34", null ],
      [ "triggerNo", "structrfc___c_m_d___t_x___t_e_s_t__s.html#a0ef95917f0b4c66cbf3b90b0abb905b1", null ],
      [ "triggerType", "structrfc___c_m_d___t_x___t_e_s_t__s.html#aca1f563f41c4e87dff7fa0ce305d2f8b", null ],
      [ "txWord", "structrfc___c_m_d___t_x___t_e_s_t__s.html#ae74083871dfa2cb7c041baed36a22eda", null ],
      [ "whitenMode", "structrfc___c_m_d___t_x___t_e_s_t__s.html#a97c043783096c5e5b3e42e762bb814ee", null ]
    ] ],
    [ "CMD_TX_TEST", "group___c_m_d___t_x___t_e_s_t.html#ga5f0768830cb57e626c3ecca1dfe0e2e4", null ]
];