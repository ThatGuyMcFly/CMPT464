var group__ccfgread__api =
[
    [ "CCFGRead_DIS_GPRAM", "group__ccfgread__api.html#gadf70dc1de9bfe6027adaa617fa8c9912", null ],
    [ "CCFGRead_EXT_LF_CLK_DIO", "group__ccfgread__api.html#gad60d6f6c3fe567b859016f610cbe8a55", null ],
    [ "CCFGRead_SCLK_LF_OPTION", "group__ccfgread__api.html#gaafceaa7474b25bfc18e1b1645f55697c", null ],
    [ "CCFGRead_XOSC_FREQ", "group__ccfgread__api.html#ga09d2c1c4bb478c173fb3e380edbdf3f3", null ],
    [ "CCFGREAD_SCLK_LF_OPTION_EXTERNAL_LF", "group__ccfgread__api.html#ga89693c1b4267df16bb875dba17bfd507", null ],
    [ "CCFGREAD_SCLK_LF_OPTION_RCOSC_LF", "group__ccfgread__api.html#ga1c5fbb91aa37d196f690fd107008f2db", null ],
    [ "CCFGREAD_SCLK_LF_OPTION_XOSC_HF_DLF", "group__ccfgread__api.html#ga506086bcd4d248b7b066f7e7d0676531", null ],
    [ "CCFGREAD_SCLK_LF_OPTION_XOSC_LF", "group__ccfgread__api.html#gaef03007430464ba136c33ed9229b74b8", null ],
    [ "CCFGREAD_XOSC_FREQ_24M", "group__ccfgread__api.html#ga7dede2ece9988103091f81a94be5d491", null ],
    [ "CCFGREAD_XOSC_FREQ_48M", "group__ccfgread__api.html#ga8ae9d8788503a323ba63ab4d50708fd6", null ],
    [ "CCFGREAD_XOSC_FREQ_HPOSC", "group__ccfgread__api.html#gaccb11f5ef0c92f43dfd4a3d2735175cb", null ]
];