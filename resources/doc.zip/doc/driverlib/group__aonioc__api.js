var group__aonioc__api =
[
    [ "AONIOC32kHzOutputDisable", "group__aonioc__api.html#ga2fb70886230a3d24b834a26e175eba8b", null ],
    [ "AONIOC32kHzOutputEnable", "group__aonioc__api.html#ga3e2fc8bb075b470beb6969cbce5e073b", null ],
    [ "AONIOCDriveStrengthGet", "group__aonioc__api.html#gaee4518dfcc4e606414e3f8592db7ce8f", null ],
    [ "AONIOCDriveStrengthSet", "group__aonioc__api.html#ga0336365271a214b4280374716e9f6dd3", null ],
    [ "AONIOCFreezeDisable", "group__aonioc__api.html#ga6ea80201fd80c9df89bf44b239908ddc", null ],
    [ "AONIOCFreezeEnable", "group__aonioc__api.html#ga415be9a200650b0c093366100fb25277", null ],
    [ "AONIOC_DRV_LVL_MAX", "group__aonioc__api.html#gadec7f51d88f6a917e7c2ec0afc8b0fe2", null ],
    [ "AONIOC_DRV_LVL_MED", "group__aonioc__api.html#ga45470275cc67b5502abc2c1ad06be535", null ],
    [ "AONIOC_DRV_LVL_MIN", "group__aonioc__api.html#ga5fc88715b0a796fa097fe097c559dd3b", null ],
    [ "AONIOC_DRV_STR_1", "group__aonioc__api.html#ga96420f730f96044c6bfcb8bdc887233a", null ],
    [ "AONIOC_DRV_STR_2", "group__aonioc__api.html#ga9a50206764e80b2f72bac586a443c0c4", null ],
    [ "AONIOC_DRV_STR_3", "group__aonioc__api.html#gaab3f3d779e99556f079e7c3b19b41a0a", null ],
    [ "AONIOC_DRV_STR_4", "group__aonioc__api.html#ga917b0e2967d38c7b2ba9c1828a3a4cf7", null ],
    [ "AONIOC_DRV_STR_5", "group__aonioc__api.html#gaa2a51f634c596263dd78887eea6c73f0", null ],
    [ "AONIOC_DRV_STR_6", "group__aonioc__api.html#ga3d8327db17289efd7ab0e97ace548e24", null ],
    [ "AONIOC_DRV_STR_7", "group__aonioc__api.html#ga54fa9c667897b70a1cc6333137d26c23", null ],
    [ "AONIOC_DRV_STR_8", "group__aonioc__api.html#ga4f86a7bda092b5df6cd06a567fac7d75", null ]
];