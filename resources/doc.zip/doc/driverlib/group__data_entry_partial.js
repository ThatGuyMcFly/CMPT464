var group__data_entry_partial =
[
    [ "rfc_dataEntryPartial_s", "structrfc__data_entry_partial__s.html", [
      [ "bEntryOpen", "structrfc__data_entry_partial__s.html#a0a08096fa5a557613e4ee6b77a572761", null ],
      [ "bFirstCont", "structrfc__data_entry_partial__s.html#afb3974918d5e9e4341ba142d014350b1", null ],
      [ "bLastCont", "structrfc__data_entry_partial__s.html#af4652b8db6044980deecb8c424a07b65", null ],
      [ "config", "structrfc__data_entry_partial__s.html#adeea217a674176001f16d84643a98d05", null ],
      [ "irqIntv", "structrfc__data_entry_partial__s.html#aa6a51805bb7a7df88c1da297e6b06c74", null ],
      [ "length", "structrfc__data_entry_partial__s.html#afcab40710ce62197cc24d88378fac7dc", null ],
      [ "lenSz", "structrfc__data_entry_partial__s.html#a1be4fc248cdd1132cbff0ca1eff4d9e3", null ],
      [ "nextIndex", "structrfc__data_entry_partial__s.html#ac47058755da6f66530c401599917a665", null ],
      [ "numElements", "structrfc__data_entry_partial__s.html#a0293cac5c4db889598bda5b7d91fe586", null ],
      [ "pktStatus", "structrfc__data_entry_partial__s.html#a0e08d9db12585cd337e22fe6c05c5f3b", null ],
      [ "pNextEntry", "structrfc__data_entry_partial__s.html#a007f1601616d20ea0f6768273df0f55f", null ],
      [ "rxData", "structrfc__data_entry_partial__s.html#a58066559ee7c9d736e78fa88dc1f357c", null ],
      [ "status", "structrfc__data_entry_partial__s.html#a3b76fb2c7e0f7046a49064dcb9def5b9", null ],
      [ "type", "structrfc__data_entry_partial__s.html#a515f17e89d4b37e323acdfa67a2cbba4", null ]
    ] ]
];