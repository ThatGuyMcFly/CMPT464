var group___c_m_d___f_s___p_o_w_e_r_u_p =
[
    [ "rfc_CMD_FS_POWERUP_s", "structrfc___c_m_d___f_s___p_o_w_e_r_u_p__s.html", [
      [ "__dummy0", "structrfc___c_m_d___f_s___p_o_w_e_r_u_p__s.html#a5e326c61c341adc78eda6f913c38357b", null ],
      [ "bEnaCmd", "structrfc___c_m_d___f_s___p_o_w_e_r_u_p__s.html#a354f90d907af7ef74f2fb63dbcfaff35", null ],
      [ "commandNo", "structrfc___c_m_d___f_s___p_o_w_e_r_u_p__s.html#acc7a439668534463107fe4567a2676c0", null ],
      [ "condition", "structrfc___c_m_d___f_s___p_o_w_e_r_u_p__s.html#aeb12403b5d37bf96fa43ea6161ded673", null ],
      [ "nSkip", "structrfc___c_m_d___f_s___p_o_w_e_r_u_p__s.html#a2937653c439645d3386e95b562b2960c", null ],
      [ "pastTrig", "structrfc___c_m_d___f_s___p_o_w_e_r_u_p__s.html#af0145fc28b7630f98c7cb7d222acc4d3", null ],
      [ "pNextOp", "structrfc___c_m_d___f_s___p_o_w_e_r_u_p__s.html#a3c862c1c87e0443d48c6d3ded00c252b", null ],
      [ "pRegOverride", "structrfc___c_m_d___f_s___p_o_w_e_r_u_p__s.html#aebb712dba778bff612598e6c2a458b8e", null ],
      [ "rule", "structrfc___c_m_d___f_s___p_o_w_e_r_u_p__s.html#a3c25511c708ef21f032a80846c5b9a46", null ],
      [ "startTime", "structrfc___c_m_d___f_s___p_o_w_e_r_u_p__s.html#a0a5dce4eb01b3068fa0ba6fd840f3c87", null ],
      [ "startTrigger", "structrfc___c_m_d___f_s___p_o_w_e_r_u_p__s.html#a52cd8c6b271e44e8133a3e2e93283356", null ],
      [ "status", "structrfc___c_m_d___f_s___p_o_w_e_r_u_p__s.html#a73e45a593e24d6e03f3a4f40c54e05ac", null ],
      [ "triggerNo", "structrfc___c_m_d___f_s___p_o_w_e_r_u_p__s.html#a7768ec1fa9b2beae02a30ccbc8e7afa6", null ],
      [ "triggerType", "structrfc___c_m_d___f_s___p_o_w_e_r_u_p__s.html#a07d5da104fbdb64d1c82fdf6391a9f4a", null ]
    ] ],
    [ "CMD_FS_POWERUP", "group___c_m_d___f_s___p_o_w_e_r_u_p.html#ga7d49d370b72a32973bf9e4509a9b4e12", null ]
];