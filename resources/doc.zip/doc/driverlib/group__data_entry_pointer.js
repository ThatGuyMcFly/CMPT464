var group__data_entry_pointer =
[
    [ "rfc_dataEntryPointer_s", "structrfc__data_entry_pointer__s.html", [
      [ "config", "structrfc__data_entry_pointer__s.html#a48b5798b2b00ab7a2482e82f0bb3c38b", null ],
      [ "irqIntv", "structrfc__data_entry_pointer__s.html#a4a8ff1d4dc6dd1a369e79b1ec9c7e243", null ],
      [ "length", "structrfc__data_entry_pointer__s.html#ad958d5f4b585b4388f12852cc955bf24", null ],
      [ "lenSz", "structrfc__data_entry_pointer__s.html#a2e13f499dbd72f6b25fbf4961eacb69c", null ],
      [ "pData", "structrfc__data_entry_pointer__s.html#aab706c723f99ed2a70a3a762a1e711bf", null ],
      [ "pNextEntry", "structrfc__data_entry_pointer__s.html#a82c3cc8c186681608b8aeecb49078e83", null ],
      [ "status", "structrfc__data_entry_pointer__s.html#a7539eb754ba3dfb9e03a9e72cbb7f9f3", null ],
      [ "type", "structrfc__data_entry_pointer__s.html#ab8f2b323d433c5e7c85fb32a36422c77", null ]
    ] ]
];