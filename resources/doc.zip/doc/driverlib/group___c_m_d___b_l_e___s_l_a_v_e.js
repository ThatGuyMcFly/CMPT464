var group___c_m_d___b_l_e___s_l_a_v_e =
[
    [ "rfc_CMD_BLE_SLAVE_s", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html", [
      [ "bEnaCmd", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#a46e2e4781de13d6a734c9e80a629711a", null ],
      [ "bOverride", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#a0f1b7e21b6b4632733e744d4d72e3a99", null ],
      [ "channel", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#a51e066a2702fe1155a8d2bbcdf92e5ae", null ],
      [ "commandNo", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#ae9310b3c7fd632e195010e4bb8174afd", null ],
      [ "condition", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#abea999a4d7a386295d81a70617e66d08", null ],
      [ "init", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#ac18b30c33a87953bf0a45c2817720149", null ],
      [ "nSkip", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#a41a4474b9d86601225a0677437f2ea3a", null ],
      [ "pastTrig", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#a1d86d895cd3cf1a521581fea213c56c7", null ],
      [ "pNextOp", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#a935b7eebd2ba50f2737d7a354c1beeb5", null ],
      [ "pOutput", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#aa34a6d95681d2ff9d18122000ca84065", null ],
      [ "pParams", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#a4f07567276f6e40d3e5577605867444d", null ],
      [ "rule", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#a8262abf494a4886d422378a6316cbcce", null ],
      [ "startTime", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#a348a721381ea9d44540c050696df6722", null ],
      [ "startTrigger", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#a06f08daaace9ce03fd24d8da79fae1f7", null ],
      [ "status", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#ad66f5acffc363f0f8443e21746c88d8c", null ],
      [ "triggerNo", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#a70e25c4e81a1f7b5040b2be3954d350e", null ],
      [ "triggerType", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#a384ca70c23cc2afcf7f101e5653bc99f", null ],
      [ "whitening", "structrfc___c_m_d___b_l_e___s_l_a_v_e__s.html#a387bb51ed7953212fbb8bb499dacb431", null ]
    ] ],
    [ "CMD_BLE_SLAVE", "group___c_m_d___b_l_e___s_l_a_v_e.html#gaebbaa3a28f6edcce05f51ba889cb3adc", null ]
];