var group___c_m_d___s_e_t___t_x___p_o_w_e_r =
[
    [ "rfc_CMD_SET_TX_POWER_s", "structrfc___c_m_d___s_e_t___t_x___p_o_w_e_r__s.html", [
      [ "commandNo", "structrfc___c_m_d___s_e_t___t_x___p_o_w_e_r__s.html#a26d201912a0f7039ee7c27ca9a99dd31", null ],
      [ "txPower", "structrfc___c_m_d___s_e_t___t_x___p_o_w_e_r__s.html#a62e7b77748642c17f6129d56df555eeb", null ]
    ] ],
    [ "CMD_SET_TX_POWER", "group___c_m_d___s_e_t___t_x___p_o_w_e_r.html#gacd8c72aa71d96e97bcb30a39c7dde174", null ]
];