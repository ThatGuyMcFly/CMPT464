var group__auxsmph__api =
[
    [ "AUXSMPHAcquire", "group__auxsmph__api.html#ga7d93c6a0d20a02b97e0e77dd21aa1985", null ],
    [ "AUXSMPHRelease", "group__auxsmph__api.html#ga18e88f8292a732d8a28e6d8f11e8f9a9", null ],
    [ "AUXSMPHTryAcquire", "group__auxsmph__api.html#ga78d71a7f7f41f350109b75beef049b03", null ],
    [ "AUX_SMPH_0", "group__auxsmph__api.html#ga250880d091db5fa4ac860bfd2abef1e5", null ],
    [ "AUX_SMPH_1", "group__auxsmph__api.html#ga15e8c4348db4f1bfbb6f3280018ae5cc", null ],
    [ "AUX_SMPH_2", "group__auxsmph__api.html#ga74de256df84253cd664dd30ddc5ab3b0", null ],
    [ "AUX_SMPH_3", "group__auxsmph__api.html#ga8a77ca0b035ae76f79013075a0b42392", null ],
    [ "AUX_SMPH_4", "group__auxsmph__api.html#gacf768b47299f99b285ff8064d2efa60d", null ],
    [ "AUX_SMPH_5", "group__auxsmph__api.html#ga44c7cbe45a6ba024c7fa469a1d4107b5", null ],
    [ "AUX_SMPH_6", "group__auxsmph__api.html#ga9e230b7c89105fb0eb8034494783f1b0", null ],
    [ "AUX_SMPH_7", "group__auxsmph__api.html#ga0c095c6e31d18bbf717ea4cb906e987b", null ],
    [ "AUX_SMPH_CLAIMED", "group__auxsmph__api.html#ga46c75aae22eb3cad33a68147d5329253", null ],
    [ "AUX_SMPH_FREE", "group__auxsmph__api.html#ga62b91d93fe8c383acfff3e7ed5219128", null ]
];