var modules =
[
    [ "Peripherals", "group__peripheral__group.html", "group__peripheral__group" ],
    [ "System Control", "group__system__control__group.html", "group__system__control__group" ],
    [ "System CPU", "group__system__cpu__group.html", "group__system__cpu__group" ],
    [ "Always-On Domain", "group__aon__group.html", "group__aon__group" ],
    [ "Auxiliary Domain", "group__aux__group.html", "group__aux__group" ],
    [ "Analog Domain", "group__analog__group.html", "group__analog__group" ],
    [ "RF Core", "group__rfc__api.html", "group__rfc__api" ],
    [ "RF Core Command API", "group__rfc.html", "group__rfc" ]
];