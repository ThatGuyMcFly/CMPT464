var group___c_m_d___t_r_i_g_g_e_r =
[
    [ "rfc_CMD_TRIGGER_s", "structrfc___c_m_d___t_r_i_g_g_e_r__s.html", [
      [ "commandNo", "structrfc___c_m_d___t_r_i_g_g_e_r__s.html#ad7ccd2c92442d9b87532ec730e69c39a", null ],
      [ "triggerNo", "structrfc___c_m_d___t_r_i_g_g_e_r__s.html#aa52d1e40584198f53ee372a32fa69c5f", null ]
    ] ],
    [ "CMD_TRIGGER", "group___c_m_d___t_r_i_g_g_e_r.html#ga3ccbdf7f886e970e212837af5c6df790", null ]
];