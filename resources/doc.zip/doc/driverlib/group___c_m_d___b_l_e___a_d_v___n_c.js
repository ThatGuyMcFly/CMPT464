var group___c_m_d___b_l_e___a_d_v___n_c =
[
    [ "rfc_CMD_BLE_ADV_NC_s", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html", [
      [ "bEnaCmd", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#a4a78a764ddc00eef40f4266e47de2940", null ],
      [ "bOverride", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#a2a91ea2e3fb19b312780156e78854ab0", null ],
      [ "channel", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#adeedf1775f76af7071de41d3e5b7729e", null ],
      [ "commandNo", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#adbb0071241e5f966943c750d042d3823", null ],
      [ "condition", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#a05757581b86dfc506ded003094c1fc50", null ],
      [ "init", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#afabe65d793b1bac09c8f380d80c3199d", null ],
      [ "nSkip", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#adb35a15a0565a96bced3ef96a5b1cdf3", null ],
      [ "pastTrig", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#ae2f42f802c08cd4b3c6f5b65359d2645", null ],
      [ "pNextOp", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#a0ed5f75ef59899f5f3aea8fe789e4997", null ],
      [ "pOutput", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#a0e85d6e89cbc5ffa174fe0617008ed45", null ],
      [ "pParams", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#a3b9dc9b9e0b62cd50d9567fc7243f275", null ],
      [ "rule", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#aba59af789153e6b753daec9df61e1966", null ],
      [ "startTime", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#aa7d2eb4bb74d670072afad331b583fa0", null ],
      [ "startTrigger", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#ab6c28c272f50d0b1af299eb7be43c627", null ],
      [ "status", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#adf3050825102b888adde744ecfda8792", null ],
      [ "triggerNo", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#a300ca57b5515da2612808f886cd4d5fa", null ],
      [ "triggerType", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#aa28292284aa835f0fea21d04b647d4c2", null ],
      [ "whitening", "structrfc___c_m_d___b_l_e___a_d_v___n_c__s.html#afe7ceeb05a13da92455d86b9cda9679a", null ]
    ] ],
    [ "CMD_BLE_ADV_NC", "group___c_m_d___b_l_e___a_d_v___n_c.html#gac8349ede29ccf6b9f2d6fbb44170d21b", null ]
];