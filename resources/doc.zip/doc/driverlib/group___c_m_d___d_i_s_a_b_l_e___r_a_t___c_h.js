var group___c_m_d___d_i_s_a_b_l_e___r_a_t___c_h =
[
    [ "rfc_CMD_DISABLE_RAT_CH_s", "structrfc___c_m_d___d_i_s_a_b_l_e___r_a_t___c_h__s.html", [
      [ "commandNo", "structrfc___c_m_d___d_i_s_a_b_l_e___r_a_t___c_h__s.html#a741dd3b43080015cf371c56a1380aa86", null ],
      [ "ratCh", "structrfc___c_m_d___d_i_s_a_b_l_e___r_a_t___c_h__s.html#a480ddc38151892f27be825eb65ae3848", null ]
    ] ],
    [ "CMD_DISABLE_RAT_CH", "group___c_m_d___d_i_s_a_b_l_e___r_a_t___c_h.html#ga25d25aecb175701f5b447b50f35bfdec", null ]
];