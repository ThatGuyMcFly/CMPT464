var group___c_m_d___p_r_o_p___t_x =
[
    [ "rfc_CMD_PROP_TX_s", "structrfc___c_m_d___p_r_o_p___t_x__s.html", [
      [ "__pad0__", "structrfc___c_m_d___p_r_o_p___t_x__s.html#a51c52ccd97eff8186e85bf830ad90413", null ],
      [ "bEnaCmd", "structrfc___c_m_d___p_r_o_p___t_x__s.html#afedd24ae4744f63f21f082f75c9266c1", null ],
      [ "bFsOff", "structrfc___c_m_d___p_r_o_p___t_x__s.html#a775f5617a6d17f97289e8009f4d9e7ee", null ],
      [ "bUseCrc", "structrfc___c_m_d___p_r_o_p___t_x__s.html#a4ebd5b219e2e94741de65b18c129d1b7", null ],
      [ "bVarLen", "structrfc___c_m_d___p_r_o_p___t_x__s.html#a2d2d30f6bd3a4fe8fd5c70b811ae83a1", null ],
      [ "commandNo", "structrfc___c_m_d___p_r_o_p___t_x__s.html#a386268a3fd777195f09733f1ee439d2e", null ],
      [ "condition", "structrfc___c_m_d___p_r_o_p___t_x__s.html#aa09bc75d130b1b71631caf80aa1156b4", null ],
      [ "nSkip", "structrfc___c_m_d___p_r_o_p___t_x__s.html#a21cc29757a3823d9f1f16236e0e36e97", null ],
      [ "pastTrig", "structrfc___c_m_d___p_r_o_p___t_x__s.html#a1448dfcf4c9af84de2e1c0c185ff7a86", null ],
      [ "pktConf", "structrfc___c_m_d___p_r_o_p___t_x__s.html#ad9ad91ff491ab6f05f9ad13b72ca7e88", null ],
      [ "pktLen", "structrfc___c_m_d___p_r_o_p___t_x__s.html#a4f99e17cb8306e6ce85c30bb88bb790a", null ],
      [ "pNextOp", "structrfc___c_m_d___p_r_o_p___t_x__s.html#a6b9abf0f309d0b7b8079b898650f7315", null ],
      [ "pPkt", "structrfc___c_m_d___p_r_o_p___t_x__s.html#ab23feaff3d6b89c88fc182a4e07dc4b7", null ],
      [ "rule", "structrfc___c_m_d___p_r_o_p___t_x__s.html#a83b0599b84db5f3c87125499599426ac", null ],
      [ "startTime", "structrfc___c_m_d___p_r_o_p___t_x__s.html#a6b09bc89100c1d5fd38108e6fb2de106", null ],
      [ "startTrigger", "structrfc___c_m_d___p_r_o_p___t_x__s.html#a56182762cd9cde24113ef461361743f7", null ],
      [ "status", "structrfc___c_m_d___p_r_o_p___t_x__s.html#a9288c3fd06152662a481fadf9c9ab03d", null ],
      [ "syncWord", "structrfc___c_m_d___p_r_o_p___t_x__s.html#a8288f7bec2d4fd5f3b4097d20ba0cb2e", null ],
      [ "triggerNo", "structrfc___c_m_d___p_r_o_p___t_x__s.html#ae126e64f3b603989cf7da18509e5b9bb", null ],
      [ "triggerType", "structrfc___c_m_d___p_r_o_p___t_x__s.html#a7ad04f08d65d129817a7a0be3ddb39c6", null ]
    ] ],
    [ "CMD_PROP_TX", "group___c_m_d___p_r_o_p___t_x.html#ga46fa6e93c57d4ae9c38148aa79e9fa91", null ]
];